@extends('base')

@section('content')
<h1>
    404
</h1>
@endsection
<?php $__env->startSection('content'); ?>
<!-- nuevo 1 -->
<div class="modal" id="modalDelete" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirm delete</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Confirm delete?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <form id="modalDeleteResourceForm" action="" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <input type="submit" class="btn btn-primary" value="Delete resource"/>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- fin nuevo 1 -->
<h1><?php echo e($enterprise); ?></h1>
<?php if(isset($message)): ?>
    <div class="alert alert-<?php echo e($type ?? 'success'); ?>" role="alert">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>
<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col"># id</th>
            <th scope="col">name</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($resource['id']); ?>

                </td>
                <td>
                    <?php echo e($resource['name']); ?>

                </td>
                <td>
                    <a href="<?php echo e(url('resource/' . $resource['id'])); ?>">show</a>
                </td>
                <td>
                    <a href="<?php echo e(url('resource/' . $resource['id'] . '/edit')); ?>">edit</a>
                    <a href="<?php echo e(route('resource.edit', $resource['id'])); ?>">edit</a>
                    <a href="<?php echo e(action([App\Http\Controllers\ResourceController::class, 'edit'], $resource['id'])); ?>">edit</a>
                </td>
                <td>
                    <!-- nuevo 2 -->
                    <form class="deleteForm" action="<?php echo e(url('resource/' . $resource['id'])); ?>" method="post">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="delete 1"/>
                    </form>
                    <a href="#" data-url="<?php echo e(url('resource/' . $resource['id'])); ?>" class="deleteLink" >delete 2</a><br>
                    <a href="javascript: void(0);" data-url="<?php echo e(url('resource/' . $resource['id'])); ?>" data-bs-toggle="modal" data-bs-target="#modalDelete">delete 3</a>
                    <!-- fin nuevo 2 -->
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a href="<?php echo e(url('resource/create')); ?>" class="btn btn-primary btn-lg" type="button">Add new resource</a>
<!-- nuevo 3 -->
<form id="deleteResourceForm" action="" method="post">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
</form>
<!-- fin nuevo 3 -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- nuevo 4 -->
<script src="<?php echo e(url('assets/js/delete.js')); ?>"></script>
<!-- nuevo 4 -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/primeraApp/resources/views/resource/index.blade.php ENDPATH**/ ?>
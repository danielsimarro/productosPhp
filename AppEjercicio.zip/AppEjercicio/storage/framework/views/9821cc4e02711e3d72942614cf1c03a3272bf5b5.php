<?php $__env->startSection('content'); ?>
<h1><?php echo e($enterprise); ?></h1>
<?php if(old('id') != ''): ?>
    <div class="alert alert-danger" role="alert">
        Error. Mira el ID.
    </div>
<?php endif; ?>
<form action="<?php echo e(url('resource')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input value="<?php echo e(old('name')); ?>" type="text" name="name" placeholder="Name of the resource" min-length="5" max-length="30" required />
    <input value="<?php echo e(old('precio')); ?>" type="number" name="precio" placeholder="Price of the resource" step="any" required />
    <input type="submit" value="Create"/>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/AppEjercicio/resources/views/resource/create.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Documento</title>
    </head>
    <body>
        <header><?php echo $__env->yieldContent('cabecera'); ?></header>
        <main>
            <?php echo $__env->yieldContent('cuerpo'); ?>
            <?php $__env->startSection('fin_cuerpo'); ?>
                <br>Muchas gracias.
            <?php echo $__env->yieldSection(); ?>
        </main>
        <footer><?php echo $__env->yieldContent('pie'); ?></footer>
    </body>
</html><?php /**PATH /var/www/html/laraveles/primeraApp/resources/views/plantilla1/index.blade.php ENDPATH**/ ?>
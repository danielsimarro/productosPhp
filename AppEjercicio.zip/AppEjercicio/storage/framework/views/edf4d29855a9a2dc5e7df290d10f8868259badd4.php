<?php $__env->startSection('content'); ?>
<h1><?php echo e($enterprise); ?></h1>
<form action="<?php echo e(url('resource')); ?>">
    
    <input value="<?php echo e($resource['id']); ?>" type="number"  placeholder="#id positive integer"  disabled />
    <input value="<?php echo e($resource['name']); ?>" type="text"  placeholder="Name of the resource" disabled />
    <input value="<?php echo e($resource['precio']); ?>" type="number"  placeholder="Price of the resource" step="any" disabled />
    <input type="submit" value="Back"/>
</form>

<table class="table table-striped"> 
    <thead>
        <tr>
            <th scope="col">
                # id
            </th>
            <th scope="col">
                Producto
            </th>
            <th scope="col">
                Precio
            </th>
        </tr>
        
    </thead>
    
    <tbody>
        <tr>
            <td>
                <?php echo e($resource ['id']); ?>

            </td>
            <td>
                <?php echo e($resource ['name']); ?>

            </td>
            <td>
                <?php echo e($resource ['precio']); ?>€
            </td>
            
            <td>
                <a href="<?php echo e(url('resource')); ?>"></a>
            </td>
        </tr>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/AppEjercicio/resources/views/resource/show.blade.php ENDPATH**/ ?>
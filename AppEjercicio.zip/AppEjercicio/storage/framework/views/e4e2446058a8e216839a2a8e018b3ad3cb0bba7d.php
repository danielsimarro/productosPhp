<?php $__env->startSection('footer'); ?>
&copy; 2021
<?php echo $__env->yieldSection(); ?><?php /**PATH /var/www/html/laraveles/AppEjercicio/resources/views/base/footer.blade.php ENDPATH**/ ?>
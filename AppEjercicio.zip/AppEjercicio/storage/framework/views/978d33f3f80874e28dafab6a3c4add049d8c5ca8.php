<?php $__env->startSection('content'); ?>

<h1><?php echo e($enterprise); ?></h1>
<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col"># id</th>
            <th scope="col">name</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <?php echo e($resource['id']); ?>

            </td>
            <td>
                <?php echo e($resource['name']); ?>

            </td>
            <td>
                <a href="<?php echo e(url('resource')); ?>">back</a>
                <a href="<?php echo e(url()->previous()); ?>">back</a>
            </td>
        </tr>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/primeraApp/resources/views/resource/show.blade.php ENDPATH**/ ?>
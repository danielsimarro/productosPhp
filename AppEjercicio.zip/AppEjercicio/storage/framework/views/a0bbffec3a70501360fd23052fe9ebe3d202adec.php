<?php
    use App\Http\Controllers\IndexController;
?>



<?php $__env->startSection('content'); ?>
    <div class="p-5 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Lista de Objetos</h1>
        <p class="col-md-8 fs-4">Pulsa en "Link to resources" para acceder a la creación de atributos
        
        <!--<a href="">about enlace 1</a>
        <a href="">about enlace 2</a>
        <a href="">about enlace 3</a>
        <a href="">about enlace 3</a>-->
        
        <!--<a href="<?php echo e($ruta); ?>">about enlace 4</a>-->
        
        .</p>
        <p class="col-md-8 fs-4">
          <a href="<?php echo e(url('resource')); ?>">Link to resources</a>.
        </p>
        <!--<button class="btn btn-primary btn-lg" type="button">Example button</button>-->
      </div>
    </div>
    <div class="row align-items-md-stretch">
      <div class="col-md-6">
        <div class="h-100 p-5 text-white bg-dark rounded-3">
          <h2>Change the background</h2>
          <p>Swap the background-color utility and add a `.text-*` color utility to mix up the jumbotron look. Then, mix and match with additional component themes and more.</p>
          <button class="btn btn-outline-light" type="button">Example button</button>
        </div>
      </div>
      <div class="col-md-6">
        <div class="h-100 p-5 bg-light border rounded-3">
          <h2>Add borders</h2>
          <p>Or, keep it light and add a border for some added definition to the boundaries of your content. Be sure to look under the hood at the source HTML here as we've adjusted the alignment and sizing of both column's content for equal-height.</p>
          <button class="btn btn-outline-secondary" type="button">Example button</button>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/AppEjercicio/resources/views/index.blade.php ENDPATH**/ ?>
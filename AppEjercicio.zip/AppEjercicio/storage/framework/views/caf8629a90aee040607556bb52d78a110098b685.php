<?php $__env->startSection('cabecera'); ?>
<h1>Cabecera</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cuerpo'); ?>
    <p>This is the main content.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pie'); ?>
    <hr>
    <p>See you.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('fin_cuerpo'); ?>
    ##parent-placeholder-33cd209771aca03410201533b16a57285d0ae0d3##
    Thank you.
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla1.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/primeraApp/resources/views/plantilla1/main.blade.php ENDPATH**/ ?>